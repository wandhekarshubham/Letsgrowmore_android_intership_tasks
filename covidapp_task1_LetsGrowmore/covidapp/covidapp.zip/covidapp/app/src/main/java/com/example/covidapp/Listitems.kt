package com.example.apiapp

class Listitems(var districtname:String, var active:String, var confirmed: String?, var deceased: String?,var recovered:String, var confirmed2: String?, var deceased2: String?,var recovered2:String)